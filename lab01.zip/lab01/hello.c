// hello.c
#include <stdio.h>

void main(){
	printf("hello, CPSC 275!\n");
}

