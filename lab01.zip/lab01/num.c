/**
* num.c
* Sean Balbale
* CPSC 275
**/

#include <stdio.h>

void main()
{
  int num1,num2;
  printf("Enter two numbers seperated by a space \n");
  scanf("%d%d",&num1,&num2);
  printf("The sum is %d \n",num1+num2);
}
